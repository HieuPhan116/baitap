import "./globals.css"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import type React from "react"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Câu Lạc Bộ Bóng Đá Tỉnh Đồng Tháp",
  description: "Thông tin chính thức về Câu Lạc Bộ Bóng Đá Tỉnh Đồng Tháp",
  openGraph: {
    title: "Câu Lạc Bộ Bóng Đá Tỉnh Đồng Tháp",
    description: "Thông tin chính thức về Câu Lạc Bộ Bóng Đá Tỉnh Đồng Tháp",
    images: [
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/z6297110300115_5f19ffe551657b20de3dc0d636f3c89d.jpg-3CVC4Gtj8RU9TxcRMKc6ExklY3MoO8.jpeg",
    ],
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="vi">
      <body className={inter.className}>{children}</body>
    </html>
  )
}

